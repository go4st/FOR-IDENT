#source("https://bioconductor.org/biocLite.R")
#biocLite("mzR")

# test to load mzML data into R
library(mzR)

# documentation
#browseVignettes("mzR")

setwd("E:/CD addin") #### Folder where your data is in


########## Tested and written for CD v.2.1


############# Defintions of files to work with

file_CD <- "compounds_CD_neg.csv"   # your Compound-Discoverer Output-File
file_MS <- "test_neg.mzML"        # your MS files after conversion to mzML


########### Defintions of mass, retention time tolerances and polarity
mass_tol_ppm <- 5
rt_tol_sec <- 10
polarity <- "neg"    ###### please chose polarity, accepted values: "pos" or "neg"
mass_proton <-    1.007276

########### Loading and manipualtion of files 

######## Compound discoverer file


cd_output <- read.csv (file_CD, sep ="\t", dec= ".", stringsAsFactors =F, na.strings = "")
#head(cd_output) #### Control, if import worked succesfully
cd_output <- cd_output[,3:5] ### Reduction to neccesary columns of CD output file
cd_output[,2] <- cd_output[,2]-mass_proton ### subtracts the mass of one proton to the mass in the CD output_file since this was automically added for the output file to obtain the molecular weight
colnames(cd_output) <- c("sum_formula", "MZ", "RT") ### set column names to sensible names


RTs <- as.vector(cd_output[,3])
masses <- as.vector (cd_output[,2])

#head(RTs)  ###### Control, if defintion of RTs worked
#head(masses) ###### Control, if defintion of masses worked

########### MS file

data_MS <- openMSfile(file_MS)   # opens files
ms_scan <- header(data_MS,)   ###
ms_data <-    data.frame(cbind(ms_scan$seqNum, ms_scan$retentionTime/60 ,ms_scan$precursorMZ, 
                               ms_scan$msLevel, ms_scan$precursorIntensity)) ### reduction to neccesary columns
colnames(ms_data) <- c("No.", "RT", "prec_MZ", "MZLevel", "prec_Int") ### set column names to sensible names

ms2 <- ms_data[ms_data[,4] == 2,] #### reduces Ms file data to MS2 infromation

######## New empty txt-files with MS2 data in FOR-IDENT format
write.table(x = "", file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), append = F, col.names = F, row.names =F, quote =F)

########## Manipualtion of data, Search for MS2 data and writing of data into export file
for (i in (1: nrow(cd_output))) {

  ############ Correction of Sum formula for postive ion mode ##################### 
  if (is.na(cd_output[i,1])== F) {
    formula_un_corr <- cd_output[i,1] ### defintion of uncorrected formula
    
    formula_corr <- gsub(pattern =" ", replacement = "", x = formula_un_corr, fixed = T )
  } 
  ###### in the case that sum formula was calculated.
  if (is.na(cd_output[i,1])== T) {
    formula_corr <- ""
  }
  
  # formula_corr ## control, if manipulation worked
  
  ##########  End of formula correction #######################
  
  
   
  mass_CD <- masses[i] ### sets values for mass to serach in MS data file
  RT_CD <-  RTs[i]    ### sets values for mass to serach in MS data file
  
  mass_tol <- mass_CD*mass_tol_ppm/10^6  # calculates mass error tolerance in Da
  RT_tol <- rt_tol_sec/60          # calculates RT tolerance in minutes
  
  #### Search and selction of precursor masses with RT and Mass tolerances
  ms2_suspect <- ms2[abs(ms2$RT - RT_CD) < RT_tol  & abs(ms2$prec_MZ - mass_CD) < mass_tol,]  
  
  #Reduction to MS2 with highest intensity of the precursor ion
  ms2_peak_max <- ms2_suspect[ms2_suspect$prec_Int == max(ms2_suspect$prec_Int),]
  
  
  #### WRITE Data into export file with the required FI-formate
    write.table(x = "", file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes blank line
    write.table(x = paste("NAME: ", mass_CD, " / ", RT_CD, sep =""), file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes NAME line
    write.table(x = paste("RETENTIONTIME: ", round(RT_CD,2),  sep =""), file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes RT line
    write.table(x = paste("PRECURSORMZ: ", round(mass_CD,4), sep =""), file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes Precursor Mass line line
    write.table(x = paste("Formula: ", formula_corr, sep =""), file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes corrected sum formula line
    
    ######## no MS2 in MS file within RT and mass tolerance
    if  (nrow(ms2_peak_max) == 0) {
      write.table(x = "N/A", file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F) ### writes blank line (no MS2 data avaiable)
    }
    ######## at least one  MS2 in MS file within RT and mass tolerance
    if  (nrow(ms2_peak_max) != 0) {
      ms2_data <- peaks(data_MS,ms2_peak_max[1,1]) ### selects and saves MS2 data
      ms2_data[,1] <- round(ms2_data[,1],4)  ### rounds mass to four decimal places
      ms2_data[,2] <- round(ms2_data[,2],0)  ### rounds intensities to integer
      
      ms2_data <- as.vector(t(ms2_data))  #### gives ms2data the required format to be written into txt file
      
      write.table(x = ms2_data, sep = "" , file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                  append = T, col.names = F, row.names =F, quote =F, eol = " ") ### writes MS2 data line
      write.table(x = "", file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                  append = T, col.names = F, row.names =F, quote =F) ### writes end of lines symbol
    }  
     write.table(x = "//", file = paste(strsplit(file_MS, split =".", fixed =T)[[1]][1],"_", polarity, "_export_CD.txt",sep=""), 
                append = T, col.names = F, row.names =F, quote =F, eol ="\n") ### writes the two "//" symbols
  
}
close(data_MS)
